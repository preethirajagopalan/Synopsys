with open("/network/scripts/av_monitoring/Input/cname_orig.txt", "r") as inFile:
    # read() the entire file as a string
    data1 = inFile.readlines()
    print(data1)
    print(type(data1))
    #reaDLINES LIST
    #READ IS str